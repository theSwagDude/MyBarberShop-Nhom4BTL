package com.mycompany.shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybarbershopApplicationTests {

	@Test
	void contextLoads() {
	}

}
